package com.example.pertemuan_13;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

public class HomeController extends Controller {
    @FXML
    private TableView<Person> personTable;
    @FXML
    private TableColumn<Person,String> nameCol;
    @FXML
    private TableColumn<Person,Integer> ageCol;
    @FXML
    private Button logOut;

    public void initialize(){
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        ageCol.setCellValueFactory(new PropertyValueFactory<>("age"));


        ObservableList<Person> personList = FXCollections.observableArrayList();
        personList.add(new Person("Charles",19));
        personList.add(new Person("Lix",20));
        personList.add(new Person("les",21));
        personTable.setItems(personList);

    }

    public void onLogoutButtonClick() throws IOException {
//        FXMLLoader loader = new FXMLLoader(getClass().getResource("Login-view.fxml"));
//        Scene scene = new Scene(loader.load());
//        stage.setScene(scene);
//        stage.setTitle("Login");
//        stage.show();

        this.switchStage("Login-view.fxml","Login");

    }


}
